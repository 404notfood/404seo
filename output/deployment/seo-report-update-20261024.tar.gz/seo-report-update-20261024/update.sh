#!/usr/bin/env bash
set -euo pipefail
umask 077

PROJECT=/home/seo/app
RELEASE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
export PATH="/opt/nvm/versions/node/v24.21.0/bin:/home/seo/.local/bin:/usr/local/bin:/usr/bin:/bin"

if [[ "$(id -un)" != seo ]]; then
  echo "Exécutez ce script sous le compte seo : sudo -iu seo"
  exit 1
fi
if [[ "$(readlink -f -- "$PROJECT")" != /home/seo/app ]]; then
  echo "Le dossier attendu /home/seo/app est absent ou redirigé. Mise à jour arrêtée."
  exit 1
fi
for command in node npm pm2 tar sha256sum flock curl; do command -v "$command" >/dev/null; done
[[ -f "$PROJECT/.env.production" ]]
[[ -f "$PROJECT/site/.next/standalone/site/server.js" ]]
[[ -d "$PROJECT/node_modules" ]]
pm2 describe 404seo-site >/dev/null
pm2 describe 404seo-api >/dev/null
exec 9>/home/seo/.report-presentation-update.lock
flock -n 9 || { echo "Une autre mise à jour du rapport est déjà en cours."; exit 1; }
(cd "$RELEASE" && sha256sum --check SHA256SUMS)

files=(
  apps/api/src/routes/audits.ts
  packages/reporter/src/index.ts
  packages/reporter/src/reportTemplate.ts
  packages/scorer/src/index.ts
  packages/shared/package.json
  packages/shared/src/index.ts
  packages/shared/src/auditFindings.ts
  packages/shared/src/checkLabels.ts
  packages/shared/src/types/auditFindings.types.ts
  'site/app/(dashboard)/audits/[id]/page.tsx'
  site/components/audit/IssueList.tsx
  site/components/audit/ThematicSection.tsx
  site/lib/check-labels.ts
)

mkdir -p /home/seo/report-backups
backup="$(mktemp /home/seo/report-backups/report-before-$(date +%Y%m%d-%H%M%S)-XXXXXX.tar.gz)"
backup_files=(site/.next)
for file in "${files[@]}"; do
  [[ -f "$RELEASE/files/$file" ]]
  if [[ -e "$PROJECT/$file" ]]; then backup_files+=("$file"); fi
done
echo "Sauvegarde du code concerné et du build actuel..."
tar -czf "$backup" -C "$PROJECT" -- "${backup_files[@]}"
echo "Sauvegarde : $backup"

rollback() {
  local status=$?
  trap - ERR
  set +e
  echo "Échec de la mise à jour : restauration de la version sauvegardée."
  if tar -xzf "$backup" -C "$PROJECT"; then
    pm2 restart 404seo-api
    pm2 restart 404seo-site
    echo "Fichiers restaurés. Vérifiez les deux services avec pm2 ls."
  else
    echo "Restauration incomplète. Archive à conserver : $backup"
  fi
  exit "$status"
}
trap rollback ERR

for file in "${files[@]}"; do
  mkdir -p -- "$(dirname -- "$PROJECT/$file")"
  cp -- "$RELEASE/files/$file" "$PROJECT/$file"
done

cd "$PROJECT"
set -a
source .env.production
set +a
export NODE_ENV=production
echo "Reconstruction du site SEO (aucune installation de dépendance ni migration)..."
npm run build --workspace=site

standalone="$PROJECT/site/.next/standalone/site"
[[ -f "$standalone/server.js" ]]
mkdir -p "$standalone/public" "$standalone/.next/static" "$standalone/.next/server"
cp -a site/public/. "$standalone/public/"
cp -a site/.next/static/. "$standalone/.next/static/"
cp -a site/.next/server/. "$standalone/.next/server/"

# Keep the existing PM2 environment and port assignments.
pm2 restart 404seo-api
pm2 restart 404seo-site
ready=false
for attempt in {1..15}; do
  if curl --fail --silent --max-time 5 http://127.0.0.1:4000/health >/dev/null \
    && curl --fail --silent --max-time 5 -H 'Host: seo.404notfood.fr' http://127.0.0.1:3030/api/auth/get-session >/dev/null; then
    ready=true
    break
  fi
  sleep 2
done
if [[ "$ready" != true ]]; then
  echo "Le site ou l’API ne répond pas après redémarrage."
  false
fi
pm2 save
trap - ERR
echo "Mise à jour terminée. Rechargez un audit et téléchargez à nouveau son PDF."
echo "Sauvegarde conservée : $backup"
