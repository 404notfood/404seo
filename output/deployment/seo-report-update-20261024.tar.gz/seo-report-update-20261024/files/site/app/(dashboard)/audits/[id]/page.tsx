"use client"

import { use, useCallback, useMemo, useState } from "react"
import Link from "next/link"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, ExternalLink, Download, Share2, AlertTriangle, XCircle, CheckCircle, Gauge, Globe, ImageIcon, LinkIcon, Link2, ShieldCheck } from "lucide-react"
import { toast } from "sonner"
import { useAudit, useAuditBreakdown } from "@/hooks/useAudits"
import { ScoreGauge } from "@/components/audit/ScoreGauge"
import { ScoreRadar } from "@/components/audit/ScoreRadar"
import { IssueList } from "@/components/audit/IssueList"
import { AuditProgress } from "@/components/audit/AuditProgress"
import { PagesBreakdownDonut } from "@/components/audit/PagesBreakdownDonut"
import { TopIssuesWidget } from "@/components/audit/TopIssuesWidget"
import { ThematicSection } from "@/components/audit/ThematicSection"
import { PagesTable } from "@/components/audit/PagesTable"
import { KeywordsTab } from "@/components/audit/KeywordsTab"
import { LinksDialog, type LinkKind } from "@/components/audit/LinksDialog"
import { apiClient } from "@/lib/api-client"
import { groupAuditFindings, isCriticalFinding } from "@seo/shared/audit-findings"

interface Props {
  params: Promise<{ id: string }>
}

function ScoreBar({ label, score }: { label: string; score: number }) {
  const color =
    score >= 75 ? "#10b981" : score >= 50 ? "#f59e0b" : "#ef4444"
  return (
    <div className="space-y-1">
      <div className="flex justify-between text-xs">
        <span className="text-slate-600 font-medium">{label}</span>
        <span className="font-bold tabular-nums" style={{ color }}>{score}</span>
      </div>
      <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
        <div
          className="h-2 rounded-full transition-all duration-700"
          style={{ width: `${score}%`, background: color }}
        />
      </div>
    </div>
  )
}

/* ——— Métrique Performance (grille) ——— */
interface PerfMetricProps {
  icon: React.ReactNode
  label: string
  value: string | null
  expected: string | null
  score: number
  status: "PASS" | "WARN" | "FAIL"
  /** Si fourni, la carte devient cliquable (ex: ouvrir la liste des liens). */
  onClick?: () => void
  /** Libellé d'action affiché en bas quand la carte est cliquable. */
  actionLabel?: string
}

function PerfMetric({ icon, label, value, expected, score, status, onClick, actionLabel }: PerfMetricProps) {
  const statusColor = status === "PASS" ? "text-emerald-600" : status === "WARN" ? "text-orange-500" : "text-red-500"
  const barColor = score >= 75 ? "#10b981" : score >= 50 ? "#f59e0b" : "#ef4444"
  const clickable = typeof onClick === "function"

  const content = (
    <>
      <div className="flex items-center gap-2">
        <div className="text-slate-400">{icon}</div>
        <span className="text-xs font-semibold text-slate-700">{label}</span>
        <span className={`ml-auto text-xs font-bold ${statusColor}`}>
          {status === "PASS" ? "OK" : status === "WARN" ? "Moyen" : "Critique"}
        </span>
      </div>
      {value && (
        <p className="text-lg font-bold text-slate-900 leading-none">{value}</p>
      )}
      {expected && (
        <p className="text-[11px] text-slate-400">Recommandé : <span className="text-blue-600 font-medium">{expected}</span></p>
      )}
      <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
        <div
          className="h-1.5 rounded-full transition-all duration-500"
          style={{ width: `${score}%`, background: barColor }}
        />
      </div>
      {clickable && actionLabel && (
        <p className="text-[11px] font-medium text-blue-600 flex items-center gap-1 pt-0.5">
          {actionLabel}
          <ExternalLink className="h-3 w-3" />
        </p>
      )}
    </>
  )

  if (clickable) {
    return (
      <button
        type="button"
        onClick={onClick}
        className="text-left p-3 rounded-xl border border-slate-100 bg-white space-y-2 transition-all hover:border-blue-300 hover:shadow-sm cursor-pointer focus:outline-none focus:ring-2 focus:ring-blue-500/30"
      >
        {content}
      </button>
    )
  }

  return (
    <div className="p-3 rounded-xl border border-slate-100 bg-white space-y-2">
      {content}
    </div>
  )
}

/* ——— Config métrique Performance par checkName ——— */
const PERF_METRICS_CONFIG: Array<{
  checkName: string
  label: string
  icon: React.ReactNode
}> = [
  { checkName: "response_time", label: "Temps de réponse", icon: <Gauge className="h-4 w-4" /> },
  { checkName: "page_size", label: "Poids de page", icon: <Globe className="h-4 w-4" /> },
  { checkName: "image_optimization", label: "Images optimisées", icon: <ImageIcon className="h-4 w-4" /> },
  { checkName: "internal_links", label: "Liens internes", icon: <LinkIcon className="h-4 w-4" /> },
  { checkName: "external_links", label: "Liens externes", icon: <Link2 className="h-4 w-4" /> },
  { checkName: "https_resources", label: "Ressources HTTPS", icon: <ShieldCheck className="h-4 w-4" /> },
]

export default function AuditDetailPage({ params }: Props) {
  const { id } = use(params)
  const { data: audit, isLoading } = useAudit(id)
  const isCompleted = audit?.status === "COMPLETED"
  const { data: breakdownData } = useAuditBreakdown(id, isCompleted)
  const [activeTab, setActiveTab] = useState("status")

  const scrollTo = useCallback((anchorId: string) => {
    setActiveTab("status")
    requestAnimationFrame(() => {
      const element = document.getElementById(anchorId)
      if (element instanceof HTMLDetailsElement) element.open = true
      element?.scrollIntoView({ behavior: "smooth", block: "start" })
    })
  }, [])

  // Dialog des liens (externes / internes). null = fermé.
  const [linksDialog, setLinksDialog] = useState<LinkKind | null>(null)

  // Agrège et déduplique les URLs de liens de toutes les pages crawlées.
  // useMemo placé avant les returns conditionnels (règles des hooks).
  const { externalLinkUrls, internalLinkUrls } = useMemo(() => {
    const external = new Set<string>()
    const internal = new Set<string>()
    for (const page of audit?.pages ?? []) {
      for (const u of page.externalLinkUrls ?? []) external.add(u)
      for (const u of page.internalLinkUrls ?? []) internal.add(u)
    }
    return {
      externalLinkUrls: Array.from(external),
      internalLinkUrls: Array.from(internal),
    }
  }, [audit?.pages])

  const allResults = useMemo(() => (audit?.pages ?? []).flatMap(page =>
    page.results.map(result => ({ ...result, pageId: page.id, pageUrl: page.url }))
  ), [audit?.pages])
  const findings = useMemo(() => groupAuditFindings(allResults), [allResults])

  if (isLoading) {
    return (
      <div className="p-8 space-y-6">
        <Skeleton className="h-8 w-48" />
        <div className="grid grid-cols-4 gap-4">
          {[1,2,3,4].map((i) => <Skeleton key={i} className="h-32" />)}
        </div>
        <Skeleton className="h-64" />
      </div>
    )
  }

  if (!audit) {
    return (
      <div className="p-8 text-center">
        <p className="text-slate-500">Audit introuvable.</p>
        <Button asChild variant="outline" className="mt-4">
          <Link href="/audits">Retour aux audits</Link>
        </Button>
      </div>
    )
  }

  const isRunning = !["COMPLETED", "FAILED", "CANCELLED"].includes(audit.status)

  const critiques = findings.filter(isCriticalFinding)
  const avertissements = findings.filter(finding => finding.status !== "PASS" && !isCriticalFinding(finding))
  const reussis = findings.filter(finding => finding.status === "PASS")
  const affectedOccurrences = findings.reduce((sum, finding) => sum + finding.affectedCount, 0)
  const affectedPages = new Set(findings.flatMap(finding => finding.occurrences
    .filter(check => check.status !== "PASS").map(check => check.pageUrl ?? check.pageId))).size
  const severityWeight = { HIGH: 3, MEDIUM: 2, LOW: 1 }
  const topIssues = findings.filter(finding => finding.status !== "PASS").map(finding => ({
    checkName: finding.checkName, category: finding.category,
    failCount: finding.failCount, warnCount: finding.warnCount, maxPriority: finding.priority,
    score: (finding.failCount * 3 + finding.warnCount) * severityWeight[finding.priority],
  })).sort((a, b) => b.score - a.score).slice(0, 10)

  // Métriques performance
  const perfByName = new Map(findings.filter(finding => finding.category === "PERFORMANCE")
    .map(finding => [finding.checkName, finding]))
  const perfMetrics = PERF_METRICS_CONFIG.flatMap(cfg => {
    const finding = perfByName.get(cfg.checkName)
    if (!finding) return []
    const values = new Set(finding.occurrences.map(check => check.value).filter(Boolean))
    return [{ ...cfg, check: { ...finding.occurrences[0], score: finding.score,
      value: values.size > 1 ? "Varie selon les pages" : finding.occurrences[0].value } }]
  })

  return (
    <div className="p-4 sm:p-6 lg:p-8">
      {/* Header */}
      <div className="mb-6 flex flex-wrap items-start justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Button asChild variant="ghost" size="sm" className="-ml-2 text-slate-500">
              <Link href="/audits">
                <ArrowLeft className="h-4 w-4 mr-1" />
                Audits
              </Link>
            </Button>
          </div>
          <h1 className="text-xl font-bold text-slate-900 flex items-center gap-2 break-all">
            <a
              href={audit.url}
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-blue-600 flex items-center gap-1.5"
            >
              {audit.url}
              <ExternalLink className="h-4 w-4" />
            </a>
          </h1>
          <p className="text-sm text-slate-400 mt-0.5">
            Projet : {audit.project.name} · {audit.project.domain}
          </p>
        </div>
        {audit.status === "COMPLETED" && (
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => {
              apiClient.shareAudit(id)
                .then(({ shareUrl }) => {
                  navigator.clipboard.writeText(shareUrl)
                  toast.success("Lien de partage copié !")
                })
                .catch(() => toast.error("Erreur lors du partage"))
            }}>
              <Share2 className="h-4 w-4 mr-2" />
              Partager
            </Button>
            <Button variant="outline" size="sm" onClick={() => {
              apiClient.downloadAuditPdf(id, new URL(audit.url).hostname)
                .catch(() => toast.error("Erreur lors de la génération du PDF"))
            }}>
              <Download className="h-4 w-4 mr-2" />
              PDF
            </Button>
          </div>
        )}
      </div>

      {/* Progression si en cours */}
      {isRunning && (
        <Card className="mb-6">
          <CardContent className="p-6">
            <AuditProgress status={audit.status} jobs={audit.jobs} />
          </CardContent>
        </Card>
      )}

      {/* Scores */}
      {audit.report && (
        <>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
            {/* Score global */}
            <Card>
              <CardContent className="p-6 flex flex-col items-center justify-center">
                <ScoreGauge score={Math.round(audit.report.scoreGlobal)} size={160} label="Score global" />
                <div className="mt-4 grid grid-cols-3 w-full text-center divide-x divide-slate-100">
                  <div>
                    <p className="text-lg font-bold text-red-500">{critiques.length}</p>
                    <p className="text-xs text-slate-400">Prioritaires</p>
                  </div>
                  <div>
                    <p className="text-lg font-bold text-orange-500">{avertissements.length}</p>
                    <p className="text-xs text-slate-400">À améliorer</p>
                  </div>
                  <div>
                    <p className="text-lg font-bold text-emerald-500">{reussis.length}</p>
                    <p className="text-xs text-slate-400">Conformes</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Scores par catégorie */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-semibold text-slate-700">Scores par catégorie</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4 pb-6">
                <ScoreBar label="Technique"   score={Math.round(audit.report.scoreTechnical)} />
                <ScoreBar label="On-Page"     score={Math.round(audit.report.scoreOnPage)} />
                <ScoreBar label="Performance" score={Math.round(audit.report.scorePerformance)} />
                <ScoreBar label="UX Mobile"   score={Math.round(audit.report.scoreUX)} />
              </CardContent>
            </Card>

            {/* Radar */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-semibold text-slate-700">Vue radar</CardTitle>
              </CardHeader>
              <CardContent>
                <ScoreRadar
                  technical={Math.round(audit.report.scoreTechnical)}
                  onPage={Math.round(audit.report.scoreOnPage)}
                  performance={Math.round(audit.report.scorePerformance)}
                  uxMobile={Math.round(audit.report.scoreUX)}
                />
              </CardContent>
            </Card>
          </div>

          {/* Stats pages */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
            {[
              { label: "Pages analysées", value: audit.pages.length },
              { label: "Types de problèmes", value: critiques.length + avertissements.length },
              { label: "Pages concernées", value: affectedPages },
              { label: "Constats sur ces pages", value: affectedOccurrences },
            ].map((s) => (
              <Card key={s.label}>
                <CardContent className="p-4 text-center">
                  <p className="text-2xl font-bold text-slate-900">{s.value}</p>
                  <p className="text-xs text-slate-400 mt-0.5">{s.label}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="mb-6 rounded-xl border border-blue-100 bg-blue-50/60 px-5 py-4">
            <p className="text-sm font-semibold text-slate-900">Une vue par problème, un détail par page</p>
            <p className="mt-1 text-sm leading-relaxed text-slate-600">Les constats répétés sont regroupés par contrôle. Ouvrez une ligne pour consulter les URL, les valeurs observées et les conseils. Les scores de l’audit conservent leur calcul d’origine.</p>
          </div>

          {/* NOUVEAU — Donut Pages Breakdown + Top Issues */}
          {breakdownData && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-semibold text-slate-700">Répartition des pages</CardTitle>
                </CardHeader>
                <CardContent>
                  <PagesBreakdownDonut
                    healthy={breakdownData.breakdown.healthy}
                    redirects={breakdownData.breakdown.redirects}
                    errors={breakdownData.breakdown.errors}
                    blocked={breakdownData.breakdown.blocked}
                  />
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-semibold text-slate-700">Top problèmes</CardTitle>
                </CardHeader>
                <CardContent>
                  <TopIssuesWidget issues={topIssues} totalPages={audit.pages.length} />
                </CardContent>
              </Card>
            </div>
          )}

          {/* Barre de navigation rapide (ancres) */}
          {allResults.length > 0 && (
            <div className="flex flex-wrap gap-3 mb-6">
              <button
                onClick={() => scrollTo("critiques")}
                className="flex items-center gap-2 px-4 py-2 rounded-full bg-red-50 border border-red-200 text-red-700 text-sm font-medium hover:bg-red-100 transition-colors"
              >
                <XCircle className="h-4 w-4" />
                Critiques ({critiques.length})
              </button>
              <button
                onClick={() => scrollTo("avertissements")}
                className="flex items-center gap-2 px-4 py-2 rounded-full bg-orange-50 border border-orange-200 text-orange-700 text-sm font-medium hover:bg-orange-100 transition-colors"
              >
                <AlertTriangle className="h-4 w-4" />
                Avertissements ({avertissements.length})
              </button>
              <button
                onClick={() => scrollTo("reussis")}
                className="flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-700 text-sm font-medium hover:bg-emerald-100 transition-colors"
              >
                <CheckCircle className="h-4 w-4" />
                Réussis ({reussis.length})
              </button>
            </div>
          )}

          {/* Section Performance dédiée */}
          {perfMetrics.length > 0 && (
            <Card className="mb-6">
              <CardHeader className="pb-3">
                <div className="flex items-center gap-3">
                  <ScoreGauge score={Math.round(audit.report.scorePerformance)} size={64} />
                  <div>
                    <CardTitle className="text-base">Métriques Performance</CardTitle>
                    <p className="text-xs text-slate-400 mt-0.5">Détail des indicateurs de vitesse et optimisation</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  {perfMetrics.map(({ checkName, label, icon, check }) => {
                    // Cartes liens : cliquables si on a stocké les URLs (audits récents).
                    const linkKind: LinkKind | null =
                      checkName === "external_links" ? "external"
                      : checkName === "internal_links" ? "internal"
                      : null
                    const linkUrls = linkKind === "external" ? externalLinkUrls
                      : linkKind === "internal" ? internalLinkUrls
                      : []
                    const isLinkCard = linkKind !== null && linkUrls.length > 0

                    return (
                      <PerfMetric
                        key={checkName}
                        icon={icon}
                        label={label}
                        value={check.value ?? null}
                        expected={check.expected ?? null}
                        score={check.score}
                        status={check.status}
                        onClick={isLinkCard ? () => setLinksDialog(linkKind) : undefined}
                        actionLabel={isLinkCard ? `Voir les ${linkUrls.length} liens` : undefined}
                      />
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          )}

          {/* === TABS : Par statut | Technique | Contenu | Performance | UX Mobile | Toutes les pages === */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-8">
            <TabsList className="mb-4 h-auto max-w-full justify-start overflow-x-auto">
              <TabsTrigger value="status">Problèmes regroupés</TabsTrigger>
              <TabsTrigger value="technical">Technique</TabsTrigger>
              <TabsTrigger value="content">Contenu</TabsTrigger>
              <TabsTrigger value="performance">Performance</TabsTrigger>
              <TabsTrigger value="ux">UX Mobile</TabsTrigger>
              <TabsTrigger value="keywords">Mots-clés</TabsTrigger>
              <TabsTrigger value="pages">Toutes les pages</TabsTrigger>
            </TabsList>

            {/* Tab : Par statut */}
            <TabsContent value="status" className="space-y-8">
              {/* Section Critiques */}
              {critiques.length > 0 && (
                <section id="critiques" className="scroll-mt-4">
                  <div className="flex items-center gap-2 mb-4">
                    <div className="h-8 w-8 rounded-full bg-red-100 flex items-center justify-center">
                      <XCircle className="h-4 w-4 text-red-500" />
                    </div>
                    <h2 className="text-lg font-bold text-red-700">
                      Problèmes critiques
                    </h2>
                    <span className="text-sm font-medium text-red-400 ml-1">({critiques.length})</span>
                  </div>
                  <IssueList findings={critiques} />
                </section>
              )}

              {/* Section Avertissements */}
              {avertissements.length > 0 && (
                <section id="avertissements" className="scroll-mt-4">
                  <div className="flex items-center gap-2 mb-4">
                    <div className="h-8 w-8 rounded-full bg-orange-100 flex items-center justify-center">
                      <AlertTriangle className="h-4 w-4 text-orange-500" />
                    </div>
                    <h2 className="text-lg font-bold text-orange-700">
                      Avertissements
                    </h2>
                    <span className="text-sm font-medium text-orange-400 ml-1">({avertissements.length})</span>
                  </div>
                  <IssueList findings={avertissements} />
                </section>
              )}

              {/* Section Réussis */}
              {reussis.length > 0 && (
                <details id="reussis" className="scroll-mt-4 rounded-xl border border-emerald-100 bg-emerald-50/30 p-4">
                  <summary className="flex cursor-pointer items-center gap-2">
                    <div className="h-8 w-8 rounded-full bg-emerald-100 flex items-center justify-center">
                      <CheckCircle className="h-4 w-4 text-emerald-500" />
                    </div>
                    <h2 className="text-lg font-bold text-emerald-700">
                      Contrôles conformes sur toutes les pages vérifiées
                    </h2>
                    <span className="text-sm font-medium text-emerald-400 ml-1">({reussis.length})</span>
                  </summary>
                  <div className="mt-4"><IssueList findings={reussis} compact /></div>
                </details>
              )}
            </TabsContent>

            {/* Tab : Technique */}
            <TabsContent value="technical">
              <ThematicSection
                category="TECHNICAL"
                score={audit.report.scoreTechnical}
                results={allResults}
              />
            </TabsContent>

            {/* Tab : Contenu */}
            <TabsContent value="content">
              <ThematicSection
                category="ON_PAGE"
                score={audit.report.scoreOnPage}
                results={allResults}
              />
            </TabsContent>

            {/* Tab : Performance */}
            <TabsContent value="performance">
              <ThematicSection
                category="PERFORMANCE"
                score={audit.report.scorePerformance}
                results={allResults}
              />
            </TabsContent>

            {/* Tab : UX Mobile */}
            <TabsContent value="ux">
              <ThematicSection
                category="UX_MOBILE"
                score={audit.report.scoreUX}
                results={allResults}
              />
            </TabsContent>

            {/* Tab : Mots-clés */}
            <TabsContent value="keywords">
              <KeywordsTab auditId={id} enabled={isCompleted} />
            </TabsContent>

            {/* Tab : Toutes les pages */}
            <TabsContent value="pages">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Toutes les pages ({audit.pages.length})</CardTitle>
                </CardHeader>
                <CardContent>
                  <PagesTable pages={audit.pages} />
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </>
      )}

      {/* Échec */}
      {audit.status === "FAILED" && (
        <Card className="border-red-100">
          <CardContent className="p-6 text-center">
            <p className="text-red-600 font-medium">L&apos;audit a échoué.</p>
            <p className="text-sm text-slate-500 mt-1">Vérifiez que l&apos;URL est accessible et relancez.</p>
            <Button asChild className="mt-4" variant="outline">
              <Link href="/audits">Retour aux audits</Link>
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Dialog liste des liens (externes / internes) */}
      <LinksDialog
        open={linksDialog !== null}
        onOpenChange={(open) => { if (!open) setLinksDialog(null) }}
        kind={linksDialog ?? "external"}
        urls={linksDialog === "internal" ? internalLinkUrls : externalLinkUrls}
        seeAllHref={`/audits/${id}/links${linksDialog === "internal" ? "?type=internal" : ""}`}
      />
    </div>
  )
}
