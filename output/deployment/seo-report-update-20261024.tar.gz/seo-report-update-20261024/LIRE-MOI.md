# Mise à jour de la présentation des audits SEO

Cette archive contient uniquement les 13 fichiers nécessaires à la refonte des
rapports. Elle n'inclut aucun secret, node_modules, build Windows, schéma Prisma,
migration, ni modification du crawler ou de l'analyseur.

## Installation

1. Transférer seo-report-update-20261024.tar.gz dans /tmp sur le VPS, avec WinSCP
   ou un autre client SFTP.
2. Dans le terminal SSH :

    sudo install -o seo -g seo -m 600 /tmp/seo-report-update-20261024.tar.gz /home/seo/seo-report-update-20261024.tar.gz
    sudo -iu seo
    tar -xzf /home/seo/seo-report-update-20261024.tar.gz -C /home/seo
    bash /home/seo/seo-report-update-20261024/update.sh

Le dossier de l'application doit être /home/seo/app. Le script vérifie les
empreintes des fichiers, crée une sauvegarde du code concerné et de site/.next
dans /home/seo/report-backups, copie les sources, reconstruit Next.js sur Linux,
copie les assets standalone, puis redémarre seulement 404seo-api et 404seo-site.
Il conserve leurs variables PM2 et leurs ports actuels. Les autres projets et
les workers ne sont pas redémarrés. Aucune migration ni installation npm n'est
effectuée. Le compte seo doit déjà disposer de ses dépendances de production et
du PATH Node.js utilisé pendant le diagnostic.

Prévoir une courte interruption de SEO : le build est produit dans le dossier
de l'application. La sauvegarde du build nécessite de la place libre sur le VPS.
En cas d'échec après la sauvegarde, le script tente de restaurer le code et le
build précédents et de redémarrer les deux services SEO. Le chemin exact de la
sauvegarde est affiché et le script sort avec un code d'erreur.

## Vérification

Recharger la page d'un audit, ouvrir un problème pour consulter les URL et
télécharger à nouveau le PDF. Les anciens fichiers PDF déjà téléchargés ne
changent pas. Aucun nouveau crawl n'est nécessaire pour cette présentation.

## Gestion des sources

Cette méthode copie les fichiers directement dans le checkout du VPS, sans
commit ni push. Les intégrer aussi au dépôt Git avant une future mise à jour
par git pull ; ne pas écraser ces changements avec un reset.

Cette archive a été préparée et vérifiée localement. Elle n'a pas été exécutée
sur le VPS depuis cette conversation.
